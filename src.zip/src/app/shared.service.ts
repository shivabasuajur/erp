import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map, catchError, retry, retryWhen, delay, scan } from 'rxjs/operators';
import { environment } from '../environments/environment';
export interface IShared {


}


const httpOptions = {
  headers: new HttpHeaders({


    'Content-Type': 'application/json',
    'Authorization': 'Basic YWRtaW46YWRtaW4='

  })
};

const httpOptionsMultipart = {
  headers: new HttpHeaders({
    'Authorization': 'Basic YWRtaW46YWRtaW4='
  })
};
@Injectable()
export class SharedService {

  constructor(private _http: HttpClient) {



  }

  private extractData(res: Response) {
    let body = res;
    return body || {};
  }




  /* ATS API*/


  checkValidToken(data: any): Observable<IShared[]> {
    return this._http.put<IShared[]>(environment.api + '/api/account-management/users/forgotpassverifytoken', data, {}).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));

  }
  changePasswordUser(add: any): Observable<IShared[]> {
    return this._http.put<IShared[]>(environment.api + '/api/account-management/users/changePass', add, {}).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));

  }
  emailVerify(token: any,userId:any): Observable<IShared[]> {
    return this._http.put<IShared[]>(environment.api + '/api/account-management/users/emailverifyToekn/'+token+"/"+userId, {}).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));

  }
  forgetPass(data: any): Observable<any[]> {
    return this._http.put<any[]>(environment.api + '/api/account-management/users/forgotPassRequest', data).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));

  }
  forgetPasswordLink(token: any,userId:any,password:any): Observable<IShared[]> {
    return this._http.put<IShared[]>(environment.api + '/api/account-management/users/forgotpassverifytoken/'+token+"/"+userId+"/"+password, {}).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));

  }
  getUserName(userName: any): Observable<any[]> {
    // /users/get/{userName}
    return this._http.get<any[]>(environment.api + '/api/account-management/users/get/' + userName).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));
  }
  getRolePermission(roleId: any): Observable<any[]> {
    return this._http.get<any[]>(environment.api + '/api/role-lookup/rolePermission/getbyroleid/' + roleId).pipe(map((response) => {
      return response
    }, catchError(this.handleError)));
  }
 updatepassword(add: any): Observable<IShared[]> {
  return this._http.put<IShared[]>(environment.api + '/api/account-management/users/updatePasswordByUserId', add, {}).pipe(map((response) => {
    return response
  }, catchError(this.handleError)));

}

  private handleError(error: any) {
    let errMsg = (error.message) ? error.message : error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    return Observable.throw(error);
  }
}
