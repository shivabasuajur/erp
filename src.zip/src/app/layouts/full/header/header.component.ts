import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: []
})
export class AppHeaderComponent {

  constructor(private router: Router){

  }

  logOut(){
   sessionStorage.removeItem('currentUser');
   localStorage.removeItem('token');
   
    this.router.navigate(['/authentication/login'])
  }
}
