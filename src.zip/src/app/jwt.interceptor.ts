import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';

// @Injectable()
// export class JwtInterceptor implements HttpInterceptor {
//   constructor(private injector: Injector) { }
//   intercept(req: any, next: any) {
//     let autoservice = this.injector.get(AuthenticationService)
//     let tokenziedReq = req.clone({
//       setHeader: {
//         Authorization: `${localStorage.getItem('token')}`
//       }
//     })
//     return next.handle(tokenziedReq)
//   }
// }


@Injectable({
  providedIn: 'root'
})
// export class JwtInterceptor implements HttpInterceptor {
//   token: any;

//   intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//     {
//       request = request.clone({
//         setHeaders: {
//           Authorization: `Bearer ${this.token}`
//         }
//       });
//     }

//     return next.handle(request);
//   }
// }


@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    token: any;
    constructor(){
        // set token if saved in session storage
        
    }
    intercept(req: HttpRequest<any>,
              next: HttpHandler): Observable<HttpEvent<any>> {

        const idToken = localStorage.getItem("token");
        console.log(idToken)
        if (idToken) {
            const cloned = req.clone({
                headers: req.headers.set("Authorization",
                    "Bearer " + idToken)
            });

            return next.handle(cloned);
        }
        else {
            return next.handle(req);
        }
    }
}

// }
