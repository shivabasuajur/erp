import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthenticationRoutingModule } from './authentication-routing.module';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPassowrdComponent } from './forgot-passowrd/forgot-passowrd.component';
import { DemoMaterialModule } from '../demo-material-module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RegsiterService } from './service/register.service';


@NgModule({
  declarations: [
    LoginComponent,
    RegisterComponent,
    ForgotPassowrdComponent
  ],
  imports: [
    CommonModule,
    AuthenticationRoutingModule,
    DemoMaterialModule,
    FlexLayoutModule
  ],
  providers: [RegsiterService]
})
export class AuthenticationModule { }
