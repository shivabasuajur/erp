import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RegsiterService } from '../service/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm :any;
  districtList: any[] = [];
  constructor(private formBuilder: FormBuilder,
    private regsiterService: RegsiterService) { }

  ngOnInit(): void {
    this.inItLoginForm();
    this.getAllDistrict();
  }

  getAllDistrict(){
    this.regsiterService.getDistrict().subscribe(data => {
      this.districtList = data;
    })
  }

  inItLoginForm(){
    this.registerForm = this.formBuilder.group({
      userName: [null,[Validators.required]],
      password: [null,[Validators.required]]
    });
  }
}
