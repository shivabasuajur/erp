import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-passowrd',
  templateUrl: './forgot-passowrd.component.html',
  styleUrls: ['./forgot-passowrd.component.scss']
})
export class ForgotPassowrdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
