import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError, retry, retryWhen, delay, scan, tap, multicast } from 'rxjs/operators';

import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})

export class RegsiterService {
  //Branch
 
  constructor(private _http: HttpClient) { }
  private extractData(res: Response) {
    let body = res;
    return body || {};
  }


  getDistrict(): Observable<any[]> {
    return this._http.get<any[]>(environment.api + '/district/all').pipe(map((response) => {
      return response
    }, catchError(this.handleError)));

  }

  private handleError(error: any) {
    let errMsg = (error.message) ? error.message : error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    return Observable.throw(error);
  }
}