import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm :any;
  loading: boolean = false;
  add: any ={};
  userName: any;
  password: any;
  constructor(private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private router :Router) {
    
     }

  ngOnInit(): void {
    this.inItLoginForm();
  }

  inItLoginForm(){
    this.loginForm = this.formBuilder.group({
      userName: [null,[Validators.required]],
      password: [null,[Validators.required]]
    });
  }


  onReset() {
    this.loginForm.reset();
  }
  get f() {
    return this.loginForm.controls;
  }


  onSubmit() {
    if (this.loginForm.invalid) {
      return
    }
    this.loading = true;

    this.add = this.loginForm.value;
    this.userName = this.add.userName;
    this.password = this.add.password;
    this.authenticationService.authenticate(this.userName, this.password)
      .subscribe(data => {
        if (data) {
          this.router.navigate(['dashboard'])
        }

      },
      (err) => {
        if (err.status == 401) {
          alert("Username Or Password Invalid")
          this.loading=false;
        }
      })
  }
  

}
