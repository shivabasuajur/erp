/**
* authentication.service.ts - a service class for Authentication.

*/
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpResponse, HttpBackend } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { of } from 'rxjs';

import { map, catchError, retry, retryWhen, delay, scan, tap } from 'rxjs/operators';

import { environment } from '../environments/environment';
import { SharedService } from '../app/shared.service';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

@Injectable()
export class AuthenticationService {
 public token: any;
 public userId: any;

 currentUser:any={}

  constructor(private http: HttpClient) {

    if(sessionStorage.getItem('currentUser') != ""){
      var currentUser = JSON.parse(sessionStorage.getItem('currentUser')|| '{}');
      this.token=currentUser  && currentUser.userId;
    }
  }

  authenticate(userName: any, password: any): Observable<any> {

    sessionStorage.setItem("currentUser", "{}");
    return this.http.post<any>(environment.api + '/api/auth/signin', { username: userName, password: password },{ observe: 'response' }).pipe(
      map((res) => {
        localStorage.setItem('token', res.body.accessToken);
       
          sessionStorage.setItem('currentUser', JSON.stringify({ userDeatils: res.body, token: res.body.accessToken}));
        
        return res;
      
      }),

    );

  }
  getToken() {
    return localStorage.getItem('token');
  }
}

